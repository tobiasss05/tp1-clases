class CuentaBancaria:
    def __init__(self, numeroCuenta, saldo=0.0):
        self.__saldo = saldo
        self.__numeroCuenta = numeroCuenta

    def depositar(self, cantidad):
        if cantidad > 0:
            self.__saldo += cantidad
            print(f"Depositado: ${cantidad} - Saldo: ${self.__saldo}")
        else:
            print("Cantidad inválida")

    def retirar(self, cantidad):
        if 0 < cantidad <= self.__saldo:
            self.__saldo -= cantidad
            print(f"Retirado: ${cantidad} - Saldo: ${self.__saldo}")
        else:
            print("Fondos insuficientes o cantidad inválida")

    def getSaldo(self):
        return self.__saldo

# Prueba
if __name__ == "__main__":
    cuenta = CuentaBancaria("12345678")
    cuenta.depositar(200.000)
    cuenta.retirar(150.000)
    print(f"Saldo final: ${cuenta.getSaldo()}")
