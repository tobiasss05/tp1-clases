from abc import ABC, abstractmethod

class Estudiante(ABC):
    @abstractmethod
    def obtenerPromedio(self): pass

    @abstractmethod
    def mostrarInformacion(self): pass

class EstudianteDeGrado(Estudiante):
    def __init__(self, nombre, notas):
        self.__nombre = nombre
        self.__notas = notas

    def obtenerPromedio(self):
        return sum(self.__notas) / len(self.__notas)

    def mostrarInformacion(self):
        print(f"Estudiante de grado: {self.__nombre} - Promedio: {self.obtenerPromedio():.2f}")

class EstudianteDeTecnicatura(Estudiante):
    def __init__(self, nombre, tesisAprobada):
        self.__nombre = nombre
        self.__tesisAprobada = tesisAprobada

    def obtenerPromedio(self):
        return 100.0 if self.__tesisAprobada else 0.0

    def mostrarInformacion(self):
        estado = "Materia aprobada" if self.__tesisAprobada else "Materia pendiente"
        print(f"Estudiante de tecnicatura: {self.__nombre} - {estado} - Promedio: {self.obtenerPromedio()}")

# Prueba
if __name__ == "__main__":
    estudiantes = [
        EstudianteDeGrado("Laura", [80, 90, 85]),
        EstudianteDeTecnicatura("Andrés", True),
        EstudianteDeGrado("Marcos", [70, 75, 80]),
        EstudianteDeTecnicatura("Lucía", False)
    ]

    for est in estudiantes:
        est.mostrarInformacion()
