class Empleado:
    def calcularSalario(self):
        return 0

class EmpleadoPorHora(Empleado):
    def __init__(self, horas, tarifa):
        self.horas = horas
        self.tarifa = tarifa

    def calcularSalario(self):
        return self.horas * self.tarifa

class EmpleadoFijo(Empleado):
    def __init__(self, salario):
        self.salario = salario

    def calcularSalario(self):
        return self.salario

# Prueba
if __name__ == "__main__":
    empleados = [
        EmpleadoPorHora(700,  800),
        EmpleadoFijo(300000),
        EmpleadoPorHora(1500, 300)
    ]

    for i, emp in enumerate(empleados):
        print(f"Empleado {i+1} - Salario: ${emp.calcularSalario()}")
